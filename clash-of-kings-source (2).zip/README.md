# Clash of Kings

## Setup

1. `npm install`
2. `npm run dev`

## Deployment to Vercel

1. Push to GitHub.
2. Import in Vercel.
3. Deploy.
